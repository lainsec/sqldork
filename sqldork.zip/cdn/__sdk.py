
banner = """ ██████   █████    ██▓   ▓█████▄  ▒█████   ██▀███   ██ ▄█▀
▒██    ▒ ▒██▓  ██▒ ▓██▒   ▒██▀ ██▌▒██▒  ██▒▓██ ▒ ██▒ ██▄█▒ 
░ ▓██▄   ▒██▒  ██░ ▒██░   ░██   █▌▒██░  ██▒▓██ ░▄█ ▒▓███▄░ 
  ▒   ██▒░██  █▀ ░ ▒██░   ░▓█▄   ▌▒██   ██░▒██▀▀█▄  ▓██ █▄ 
▒██████▒▒░▒███▒█▄ ▒░██████░▒████▓ ░ ████▓▒░░██▓ ▒██▒▒██▒ █▄
▒ ▒▓▒ ▒ ░░░ ▒▒░ ▒ ░░ ▒░▓   ▒▒▓  ▒ ░ ▒░▒░▒░ ░ ▒▓ ░▒▓░▒ ▒▒ ▓▒
░ ░▒  ░ ░ ░ ▒░  ░ ░░ ░ ▒   ░ ▒  ▒   ░ ▒ ▒░   ░▒ ░ ▒ ░ ░▒ ▒░
░  ░  ░     ░   ░    ░ ░   ░ ░  ░ ░ ░ ░ ▒    ░░   ░ ░ ░░ ░ 
      ░      ░    ░    ░     ░        ░ ░     ░     ░  ░
"""
options = """
Choose any option below:

[1] Sqldirb

[2] find sqldork (not working yet)
"""

start = "[*] Brute force started..."

error = "Your connection was lost, pls check and try again."

error2 = "Oh no! something happened, please check the url and try again."

appear = "\n[!] The website apear to have SQLi, testing...\n"

test_payload = "[*] using payload -> "

found = "[*] Failure found --> "

op1 = "Insert the website's url on the input below:"

verbose = "Do you want to apply the verbose mode ? [y/N]"

inputc = "~/sqldork#$ "

if __name__ == "__main__":
    print('module working')
