
banner = """ ██████   █████    ██▓   ▓█████▄  ▒█████   ██▀███   ██ ▄█▀
▒██    ▒ ▒██▓  ██▒ ▓██▒   ▒██▀ ██▌▒██▒  ██▒▓██ ▒ ██▒ ██▄█▒ 
░ ▓██▄   ▒██▒  ██░ ▒██░   ░██   █▌▒██░  ██▒▓██ ░▄█ ▒▓███▄░ 
  ▒   ██▒░██  █▀ ░ ▒██░   ░▓█▄   ▌▒██   ██░▒██▀▀█▄  ▓██ █▄ 
▒██████▒▒░▒███▒█▄ ▒░██████░▒████▓ ░ ████▓▒░░██▓ ▒██▒▒██▒ █▄
▒ ▒▓▒ ▒ ░░░ ▒▒░ ▒ ░░ ▒░▓   ▒▒▓  ▒ ░ ▒░▒░▒░ ░ ▒▓ ░▒▓░▒ ▒▒ ▓▒
░ ░▒  ░ ░ ░ ▒░  ░ ░░ ░ ▒   ░ ▒  ▒   ░ ▒ ▒░   ░▒ ░ ▒ ░ ░▒ ▒░
░  ░  ░     ░   ░    ░ ░   ░ ░  ░ ░ ░ ░ ▒    ░░   ░ ░ ░░ ░ 
      ░      ░    ░    ░     ░        ░ ░     ░     ░  ░
"""
options = """
Choose any option below:

[1] Sqldirb

[2] find sqldork (not working yet)
"""

error = "Your connection was lost, pls check and try again."

op1 = "Put the website's url on the input below:"

inputc = "~/sqldork#$ "
