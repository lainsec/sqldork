
banner = """ ██████   █████    ██▓   ▓█████▄  ▒█████   ██▀███   ██ ▄█▀
▒██    ▒ ▒██▓  ██▒ ▓██▒   ▒██▀ ██▌▒██▒  ██▒▓██ ▒ ██▒ ██▄█▒ 
░ ▓██▄   ▒██▒  ██░ ▒██░   ░██   █▌▒██░  ██▒▓██ ░▄█ ▒▓███▄░ 
  ▒   ██▒░██  █▀ ░ ▒██░   ░▓█▄   ▌▒██   ██░▒██▀▀█▄  ▓██ █▄ 
▒██████▒▒░▒███▒█▄ ▒░██████░▒████▓ ░ ████▓▒░░██▓ ▒██▒▒██▒ █▄
▒ ▒▓▒ ▒ ░░░ ▒▒░ ▒ ░░ ▒░▓   ▒▒▓  ▒ ░ ▒░▒░▒░ ░ ▒▓ ░▒▓░▒ ▒▒ ▓▒
░ ░▒  ░ ░ ░ ▒░  ░ ░░ ░ ▒   ░ ▒  ▒   ░ ▒ ▒░   ░▒ ░ ▒ ░ ░▒ ▒░
░  ░  ░     ░   ░    ░ ░   ░ ░  ░ ░ ░ ░ ▒    ░░   ░ ░ ░░ ░ 
      ░      ░    ░    ░     ░        ░ ░     ░     ░  ░
"""
options = """
Choose any option below:

[1] Sqldirb

[2] find sqldork (not working yet)
"""

start = "[*] Brute force started..."

error = "Your connection was lost, pls check and try again."

appear = "\n[!] The website apear to have SQLi, testing...\n"

test_payload = "[*] using payload -> "

found = "[*] Failure found --> "

op1 = "Put the website's url on the input below:"

inputc = "~/sqldork#$ "
