import requests
import json
import os
from config import load_config
from colorama import Fore
from time import sleep
from cdn import __sdk

def test_connection():
    try:
        clear_t()
        print(Fore.GREEN + 'Testing your connection...',Fore.RESET)
        sleep(0.8)
        requests.get('https://google.com/')
    except:
        clear_t()
        print(Fore.RED + __sdk.error)
        sleep(2)
        clear_t()
        exit()

def url_format(url):
    if url.startswith("https://") and url.endswith('='):
        sql_tester(url)
    elif url.startswith("http://") and url.endswith('='):
        sql_tester(url)
    elif url.startswith("https://") and url.endswith('/'):
        formatted_url = url
    elif url.startswith("https://") and not url.endswith('/'):
        formatted_url = f'{url}/'
    elif url.startswith("http://") and url.endswith('/'):
        formatted_url = url
    elif url.startswith("http://") and not url.endswith('/'):
        formatted_url = f'{url}/'
    elif not url.startswith("https://") and not url.startswith("http://") and url.endswith('/'):
        formatted_url = "https://" + url
    elif not url.startswith("https://") and not url.startswith("http://") and not url.endswith('/'):
        formatted_url = "https://" + url + '/'
    return formatted_url

def clear_sc():
    get_system = platform.system()
    if get_system == 'Windows':
        os.system('cls')
        print(__sdk.banner)
    else:
        os.system('clear')
        print(__sdk.banner)

def clear_t():
    get_system = platform.system()
    if get_system == 'Windows':
        os.system('cls')
    else:
        os.system('clear')

def sql_tester(url):
    clear_sc()
    print(Fore.GREEN + __sdk.start,Fore.RESET)
    try:
        with open(f'dorkwl/payloads/{load_config.payloads}','r') as pl:
            for line in pl:
                payload = line.strip()
                try:      
                    new_url = f"{url}{payload}"
                    tst_sqli = requests.get(f"{new_url}")
                    data = tst_sqli.text
                    if 'Fatal error' or 'Syntax error' in data:
                        print(Fore.RED + __sdk.appear,Fore.RESET)
                        sleep(3)
                        print(Fore.BLUE + f'{__sdk.test_payload}{payload}\n')
                        sleep(0.8)
                        print(Fore.GREEN + __sdk.found + f'{url}{payload}\n',Fore.RESET)
                        break
                    
                except Exception as e:
                    print(Fore.RED + f'[!] sqldork erro: {e}')
            input('Press enter:')
    except Exception as e:
        print(Fore.RED + f'[!] sqldork erro: {e}')

def op1f(url,debug):
    clear_sc()
    found_vulnerability = False
    debug_mode = debug
    notfound = Fore.YELLOW
    found = Fore.GREEN
    print(Fore.GREEN + __sdk.start,Fore.RESET)
    with open(f'dorkwl/parameters/{load_config.wordlist1}','r') as wl:
        for line in wl:
            if found_vulnerability:
                break
            parameter = line.strip()
            try:
                with open(f'dorkwl/payloads/{load_config.payloads}','r') as pl:
                    for line in pl:
                        payload = line.strip()
                        try:      
                            new_url = f"{url}{parameter}{payload}"
                            found_u = requests.get(f"{url}{parameter}")
                            if 'y'.lower() in debug_mode.lower():
                                print(notfound + f'[{found_u.status_code}] -> {url}{parameter}',Fore.RESET)
                                sleep(0.1)
                                clear_sc()
                            if found_u.status_code == 404:
                                break
                            if found_u.status_code == 200:
                                if 'y'.lower() in debug_mode.lower():
                                    print(found + f'[{found_u.status_code}] Found -> {url}{parameter}\n',Fore.RESET)
                                tst_sqli = requests.get(f"{new_url}")
                                data = tst_sqli.text
                                if 'Fatal error' or 'Syntax error' in data:
                                    if 'y'.lower() in debug_mode.lower():
                                        print(f'[{tst_sqli.status_code}] -> {payload}')
                                    print(Fore.RED + __sdk.appear)
                                    sleep(3)
                                    print(Fore.BLUE + f'{__sdk.test_payload}{payload}\n')
                                    sleep(0.8)
                                    print(Fore.GREEN + __sdk.found + f'{url}{parameter}\n',Fore.RESET )
                                    found_vulnerability = True
                                    break
                            
                        except Exception as e:
                            print(Fore.RED + f'[!] sqldork erro: {e}')
            except Exception as e:
                print(Fore.RED + f'[!] sqldork erro: {e}')       
        input('Press enter:')

def opt1():
    clear_sc()
    print(__sdk.op1)
    url = input(__sdk.inputc)
    debug = input(f'\n{__sdk.verbose}')
    if url == '':
        return
    formated_url = url_format(url)
    try:
        op1f(formated_url,debug)
    except Exception as e:
        print(Fore.RED + f'[!] sqldork erro: {e}')
        sleep(1)

def opt2():
    return
    
def option(opt):
    if opt == 1:
       opt1()
    elif opt == 2:
       opt2()
        
def choose():
    clear_sc()
    print(__sdk.options)
    opt = int(input(__sdk.inputc))
    option(opt)

if __name__ == '__main__':
    try:
        test_connection()
    except Exception as e:
        print(e)
        clear_t()
        exit()
    except KeyboardInterrupt:
        clear_t()
        exit()
    while True:
        try:
            choose()
        except Exception as e:
            print(Fore.GREEN + f'[!] sqldork erro: {e}',Fore.RESET)
        except KeyboardInterrupt:
            clear_t()
            exit()
