__doc__ = 'This module have as objective serve the sqldork program main app.'


import platform
import requests

def test_connection():
    """
        This function try the connection to google.com and if it goes wrong then return False else return True.
    """
    try:
        connection = requests.get('https://google.com/')
        return True
    except:
        return False

def format_url(url):
    """
         This function get the url and try to format it to a correct form.
    """
    if url.startswith("https://") and url.endswith('='):
        sql_tester(url)
    elif url.startswith("http://") and url.endswith('='):
        sql_tester(url)
    elif url.startswith("https://") and url.endswith('/'):
        formatted_url = url
    elif url.startswith("https://") and not url.endswith('/'):
        formatted_url = f'{url}/'
    elif url.startswith("http://") and url.endswith('/'):
        formatted_url = url
    elif url.startswith("http://") and not url.endswith('/'):
        formatted_url = f'{url}/'
    elif not url.startswith("https://") and not url.startswith("http://") and url.endswith('/'):
        formatted_url = "https://" + url
    elif not url.startswith("https://") and not url.startswith("http://") and not url.endswith('/'):
        formatted_url = "https://" + url + '/'
    return formatted_url

def get_system():
    """
        this function get the system name and if it's Windows then return True.
    """
    os_name = platform.system()
    if os_name == 'Windows':
        return True
    else:
        return False

if __name__ == '__main__':
    print('module working')

