import json

def load_config():
    with open('./config/config.json','r') as config:
        global wordlist1, payloads
        configure = json.load(config)
        wordlist1 = configure['wordlist']
        payloads = configure['payloads']

load_config()

if __name__ == '__main__':
    print('module working')

